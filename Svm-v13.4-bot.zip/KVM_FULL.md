# SVM KVM Full Stack — AnkitCoder

## Host prep
```bash
sudo bash install.sh upgrade
sudo bash install.sh --with-virt
# Discord:
!kvm-install confirm
!kvm-status
!kvm-summary
```

```bash
sudo mkdir -p /var/lib/svm/images /var/lib/svm/vms
# Place cloud-init qcow2:
#   /var/lib/svm/images/ubuntu-22.04-cloudimg.qcow2
```

`.env`:
```
KVM_BASE_IMAGE=/var/lib/svm/images/ubuntu-22.04-cloudimg.qcow2
KVM_IMAGE_DIR=/var/lib/svm/images
KVM_VM_DIR=/var/lib/svm/vms
KVM_NETWORK=default
KVM_ADDON_PRICE_INR=10
```

## Commands
| Command | Who | Action |
|---------|-----|--------|
| `!kvm-status` | all | Host capability flags |
| `!kvm-summary` | all | Ready + image/VM counts |
| `!kvm-images` | all | qcow2 inventory |
| `!kvm-list` | all | Domains |
| `!kvm-info <name>` | all | Status + addresses |
| `!kvm-create <name> [ram] [cpu] [disk]` | admin | Direct create |
| `!kvm-start/stop/reboot <name>` | admin | Lifecycle |
| `!kvm-delete <name> confirm` | admin | Destroy |
| `!create-vps … kvm` | admin | Create-VPS path |
| `!kvm-buy` / `!buy kvm-starter` | user | Paid auto-create |
| `!buy kvm-basic` / `kvm-pro` | user | Higher plans |

## Paid plans
- `kvm-starter` (₹10 default)
- `kvm-basic` (₹49 default)
- `kvm-pro` (₹99 default)

## Networking truth
Libvirt `default` network is usually **private NAT**. Public SSH needs `!ports` / IPAM portfwd — SVM does not claim EXTERNAL_VERIFIED from domain create alone.
