# SVM Advanced AI **V13.3** — Upgrade System Guide
**Made by AnkitCoder**

Email / support contact: set `SUPPORT_EMAIL` in `.env` (example: `support@yourdomain.com`).

Package: `SVM-Advanced-AI-V13.3-AnkitCoder.zip`

---

## 1. What V13.3 is

Production Discord + web VPS control plane:

- LXC (primary auto-provision) + **full KVM** lifecycle
- IPAM / topology / discovery (`ips.txt` / `ips.json`)
- Payments (Razorpay / UPI / Stripe paths as configured)
- WebSSH · File Manager · **Admin Users tab** on port **5000**
- Webhooks port **8787**
- `!askai` with **Ollama or LocalAI** (`AI_PROVIDER=auto`)
- Manage buttons + **manage-shared** for co-admins of a VPS

**Does not** invent public IPv4 ownership or claim EXTERNAL_VERIFIED without a real probe.

---

## 2. Safe upgrade

```bash
sudo bash install.sh backup
unzip -o SVM-Advanced-AI-V13.3-AnkitCoder.zip -d /tmp/svm-v13.3
cd /tmp/svm-v13.3
sudo bash install.sh upgrade
# typical single-public-IP host:
sudo sed -i 's/^IPAM_BIND_MODE=.*/IPAM_BIND_MODE=portfwd/' /opt/svm/.env
sudo systemctl restart svm
sudo bash install.sh doctor
```

Rollback: `sudo bash install.sh rollback`

---

## 3. Modules (one by one)

| # | File | Purpose |
|---|------|---------|
| 1 | `bot.py` | Discord cmds + Flask panel |
| 2 | `svm12.py` | Plans, payments, LXC/KVM providers |
| 3 | `svm_ipam.py` | IP lifecycle |
| 4 | `svm_net.py` | Firewall mapping |
| 5 | `svm_ssh.py` | SSH diagnose |
| 6 | `svm_files.py` | SFTP backend |
| 7 | `svm_dns.py` | DNS adapters |
| 8 | `svm_tools.py` | Tool registry |
| 9 | `svm_topology.py` | Topology class |
| 10 | `svm_map.py` | Modes A–E |
| 11 | `svm_ip_discovery.py` | Auto inventory |
| 12 | `svm_kvm.py` | KVM create/start/stop/delete/list |
| 13 | `svm_neofetch.py` | Status SVG/PNG |
| 14 | `install.sh` | Installer |
| 15 | `admin.html` / `webssh.html` / `filemanager.html` | Web UI |

---

## 4. Discord commands (rechecked)

### Core ops
| Command | Function |
|---------|----------|
| `!create` / `!create-vps` / `!cv` | Admin create LXC or `… kvm` |
| `!manage` | Owner/admin manage buttons |
| `!manage-shared` / `!ms` | Manage **shared** VPS |
| `!list-shared` / `!myshares` | See shares in/out |
| `!share-user` / `!share-ruser` | Grant / revoke share |

### Shared flow (working path)
1. Owner: `!share-user @friend 1`
2. Friend: `!list-shared`
3. Friend: `!manage-shared @owner 1` → same manage buttons (no admin delete)

### KVM
`!kvm-dev` · `!kvm-status` · `!kvm-summary` · `!kvm-list` · `!kvm-create` · `!kvm-start/stop/reboot` · `!kvm-delete … confirm` · `!kvm-buy`

### Network
`!autopool scan` · `!ipscan` · `!ports` · `!vpsmap`

### AI
`!askai …` · `!askai models` · `!ollama-models`  
Env: `AI_PROVIDER=auto` · `OLLAMA_BASE_URL` · `OLLAMA_MODEL`

### Payments
`!plans` · `!buy` · `!orders` · `!billing` (duplicates removed — single registration)

**Command audit:** duplicate `@bot.command` names for ports/plans/buy/orders/billing → **NONE**.

---

## 5. Admin web panel

`http://YOUR_IP:5000/admin`

Tabs: Overview · **Users** · Nodes & VPS · IP · Ports · SSH · Sessions · Admins · Config

Users tab: search Discord user IDs, VPS counts, open per-user VPS list.

---

## 6. Custom icons (online / GitHub)

### Server emoji (Discord selects)
```bash
OS_CUSTOM_EMOJIS=ubuntu:22.04=<:ubuntu:1234567890>,images:debian/12=<:debian:1234567891>
```

### CDN / GitHub raw (HTTPS)
```bash
OS_ICON_URLS=ubuntu:22.04=https://raw.githubusercontent.com/YOUR_ORG/assets/main/os/ubuntu.png,images:debian/12=https://cdn.jsdelivr.net/gh/YOUR_ORG/assets/os/debian.png
```

Upload emoji on **your** Discord server; raw GitHub links work for image URLs only (not as Discord emoji syntax).

Optional:
```bash
SUPPORT_EMAIL=support@yourdomain.com
OWNER_BANNER_URL=https://raw.githubusercontent.com/.../banner.png
```

---

## 7. Proof assets (SVG + PNG)

Path: `docs/upgrade_proof/`

| File | Marks |
|------|--------|
| `proof-01` | V13.3 overview |
| `proof-02` | IPAM + discovery |
| `proof-03` | KVM stack |
| `proof-04` | Manage buttons |
| `proof-05` | Ollama / askai |
| `proof-06` | Duplicate cmds fixed |
| `proof-07` | manage-shared + Users panel |

These are upgrade **markers**, not public-IP certificates.

---

## 8. Env essentials

```bash
DISCORD_TOKEN=
MAIN_ADMIN_ID=
YOUR_SERVER_IP=
IPAM_BIND_MODE=portfwd
AI_PROVIDER=auto
OLLAMA_BASE_URL=http://127.0.0.1:11434
OLLAMA_MODEL=llama3.2
KVM_BASE_IMAGE=/var/lib/svm/images/ubuntu-22.04-cloudimg.qcow2
SUPPORT_EMAIL=support@yourdomain.com
```

---

## 9. Honest test labels

| Item | Label |
|------|--------|
| Unit tests (sandbox) | PASS when deps present |
| Duplicate commands | PASS (NONE) |
| manage-shared code path | PASS (wired + aliases) |
| Live KVM on host | Needs `/dev/kvm` + image |
| Live Ollama | Needs running daemon |
| Public EXTERNAL_VERIFIED | NOT TESTED in package build |

---

**AnkitCoder · SVM Advanced AI V13.3**
