# SVM Advanced AI V13.3 — AnkitCoder

Ultra networking, KVM, Ollama/LocalAI, manage + **manage-shared**, admin Users tab.

| | |
|---|---|
| **Version** | **13.3** |
| **Install** | `sudo bash install.sh` |
| **Upgrade** | `sudo bash install.sh upgrade` |
| **Full guide** | [UPGRADE_SYSTEM.md](UPGRADE_SYSTEM.md) |
| **Proof cards** | `docs/upgrade_proof/` |

```bash
!create 2 1 20 @user 30
!create 2 1 20 @user 30 kvm
!manage
!share-user @friend 1
!manage-shared @owner 1
!list-shared
!askai hello
!kvm-dev
```

Web: `:5000` WebSSH · `/filemanager` · `/admin` · webhook `:8787`

Support email: set `SUPPORT_EMAIL` in `.env`.

Custom OS icons: `OS_CUSTOM_EMOJIS` + `OS_ICON_URLS` (GitHub raw / CDN) — see UPGRADE_SYSTEM.md.
