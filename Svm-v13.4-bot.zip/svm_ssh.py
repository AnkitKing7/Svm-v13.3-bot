"""
SVM Advanced AI V13 — Universal SSH connectivity, diagnostics & verification
Made by AnkitCoder.

States (never fabricate):
  SSH_SERVICE_RUNNING   — systemd/unit reports active
  SSH_PORT_LISTENING    — something is bound to the expected port
  SSH_TCP_REACHABLE     — TCP connect succeeds from this host
  SSH_BANNER_OK         — remote spoke an SSH protocol banner
  SSH_AUTHENTICATED     — authorized login + harmless command succeeded
  SSH_READY             — service + listener verified (local or via management)
  SSH_REACHABLE         — network path works
  END_TO_END_VERIFIED   — AUTHENTICATED from the intended path (public/NAT)

Never expose private keys or passwords in logs, bot messages or DB.
Default username root and port 22 only when the image/policy permits.
"""
from __future__ import annotations

import logging
import re
import shutil
import socket
import subprocess
import time
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional, Sequence, Tuple

logger = logging.getLogger("svm.ssh")

DEFAULT_USER = "root"
DEFAULT_PORT = 22
PROBE_TIMEOUT = 8
AUTH_TIMEOUT = 25


@dataclass
class SSHStatus:
    host: str
    port: int = DEFAULT_PORT
    username: str = DEFAULT_USER
    service_running: Optional[bool] = None
    port_listening: Optional[bool] = None
    tcp_reachable: Optional[bool] = None
    banner_ok: Optional[bool] = None
    banner_text: str = ""
    authenticated: Optional[bool] = None
    end_to_end: Optional[bool] = None
    host_key_fingerprint: str = ""
    error: str = ""
    detail: str = ""
    checked_at: float = 0.0

    def overall(self) -> str:
        if self.authenticated:
            return "SSH_AUTHENTICATED"
        if self.banner_ok and self.tcp_reachable:
            return "SSH_REACHABLE"
        if self.port_listening or self.service_running:
            return "SSH_READY"
        if self.tcp_reachable is False:
            return "SSH_UNREACHABLE"
        return "SSH_UNKNOWN"

    def as_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        d["overall"] = self.overall()
        return d


def _run(argv: Sequence[str], timeout: int = 15) -> subprocess.CompletedProcess:
    return subprocess.run(list(argv), capture_output=True, text=True, timeout=timeout)


def detect_sshd_service() -> Dict[str, Any]:
    """Detect OpenSSH server package/service on the local host."""
    out: Dict[str, Any] = {
        "sshd_binary": shutil.which("sshd"),
        "ssh_binary": shutil.which("ssh"),
        "service_names": [],
        "active": None,
        "config_test": None,
        "listen_ports": [],
    }
    for name in ("ssh", "sshd", "openssh-server"):
        try:
            r = _run(["systemctl", "is-active", name], timeout=5)
            if r.returncode == 0 and r.stdout.strip() == "active":
                out["service_names"].append(name)
                out["active"] = True
                break
            if r.stdout.strip() in ("inactive", "failed"):
                out["service_names"].append(name)
        except Exception:
            pass
    if out["active"] is None and out["service_names"]:
        out["active"] = False

    if out["sshd_binary"]:
        try:
            r = _run([out["sshd_binary"], "-t"], timeout=5)
            out["config_test"] = "ok" if r.returncode == 0 else (r.stderr or r.stdout or "fail")[:200]
        except Exception as e:
            out["config_test"] = str(e)

    # ss -ltnp or netstat
    try:
        r = _run(["ss", "-ltnp"], timeout=5)
        if r.returncode == 0:
            for ln in r.stdout.splitlines():
                if ":22 " in ln or "sshd" in ln:
                    out["listen_ports"].append(ln.strip()[:120])
    except Exception:
        pass
    return out


def tcp_probe(host: str, port: int, timeout: float = PROBE_TIMEOUT
              ) -> Tuple[str, str]:
    """
    Returns (state, detail) where state is one of:
      ssh | other | closed | silent | refused | timeout | unreachable
    """
    try:
        sock = socket.create_connection((host, int(port)), timeout=timeout)
    except ConnectionRefusedError:
        return "refused", "connection refused"
    except socket.timeout:
        return "timeout", "connect timeout"
    except OSError as e:
        return "unreachable", str(e)
    try:
        sock.settimeout(timeout)
        data = sock.recv(64)
        txt = data.decode("latin-1", errors="replace") if data else ""
        if txt.startswith("SSH-"):
            return "ssh", txt.strip()[:80]
        if not data:
            return "silent", "accepted but no banner"
        return "other", txt[:60]
    except socket.timeout:
        return "silent", "no banner within timeout"
    except Exception as e:
        return "closed", str(e)
    finally:
        try:
            sock.close()
        except Exception:
            pass


def authenticate(host: str, port: int, username: str,
                 password: Optional[str] = None,
                 key_filename: Optional[str] = None,
                 timeout: int = AUTH_TIMEOUT,
                 command: str = "id -u") -> Tuple[bool, str]:
    """
    Real login test using paramiko when available.
    Never logs the password or private key material.
    """
    try:
        import paramiko
    except ImportError:
        return False, "paramiko not installed"

    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.RejectPolicy())
    # Allow AutoAdd only for explicit diagnostic runs; prefer known_hosts
    # For automation we still use AutoAdd but record fingerprint.
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
        kwargs: Dict[str, Any] = {
            "hostname": host,
            "port": int(port),
            "username": username,
            "timeout": timeout,
            "allow_agent": False,
            "look_for_keys": False,
        }
        if key_filename:
            kwargs["key_filename"] = key_filename
        elif password is not None:
            kwargs["password"] = password
        else:
            return False, "No credentials provided (password or key_filename required)"
        client.connect(**kwargs)
        # host key fingerprint
        transport = client.get_transport()
        fp = ""
        if transport:
            key = transport.get_remote_server_key()
            fp = key.get_fingerprint().hex() if hasattr(key.get_fingerprint(), "hex") else str(key.get_fingerprint())
        stdin, stdout, stderr = client.exec_command(command, timeout=10)
        out = (stdout.read() or b"").decode("utf-8", errors="replace").strip()
        err = (stderr.read() or b"").decode("utf-8", errors="replace").strip()
        client.close()
        if out or not err:
            return True, f"authenticated (fp={fp[:32]}… cmd_out={out[:80]})"
        return False, f"command failed: {err[:120]}"
    except paramiko.AuthenticationException:
        return False, "authentication failed (bad credentials)"
    except paramiko.SSHException as e:
        return False, f"SSH protocol error: {e}"
    except Exception as e:
        return False, f"{type(e).__name__}: {e}"


def diagnose(host: str, port: int = DEFAULT_PORT, username: str = DEFAULT_USER,
             password: Optional[str] = None, key_filename: Optional[str] = None,
             do_auth: bool = False) -> SSHStatus:
    """Full diagnostic path. Auth only when do_auth=True and credentials given."""
    st = SSHStatus(host=host, port=port, username=username, checked_at=time.time())
    state, detail = tcp_probe(host, port)
    st.tcp_reachable = state not in ("refused", "timeout", "unreachable")
    st.banner_ok = state == "ssh"
    st.banner_text = detail if state == "ssh" else ""
    st.detail = f"tcp={state}: {detail}"

    if state == "ssh" and do_auth and (password is not None or key_filename):
        ok, msg = authenticate(host, port, username, password=password,
                               key_filename=key_filename)
        st.authenticated = ok
        st.end_to_end = ok
        st.detail += f" | auth={msg}"
        if not ok:
            st.error = msg
    return st


def connection_profile(host: str, port: int = DEFAULT_PORT,
                       username: str = DEFAULT_USER,
                       auth_method: str = "password",
                       note: str = "") -> Dict[str, str]:
    """
    Termius / OpenSSH compatible connection profile (no secrets).
    """
    ssh_cmd = f"ssh -p {port} {username}@{host}"
    config_snippet = (
        f"Host svm-{host.replace('.', '-')}\n"
        f"  HostName {host}\n"
        f"  Port {port}\n"
        f"  User {username}\n"
        f"  IdentitiesOnly yes\n"
    )
    return {
        "hostname": host,
        "port": str(port),
        "username": username,
        "auth_method": auth_method,
        "ssh_command": ssh_cmd,
        "openssh_config": config_snippet,
        "termius_hint": f"Host={host} Port={port} User={username}",
        "note": note or (
            "For NAT/port-forward the external port may differ from internal 22. "
            "Use the public host port shown by !ports / !vps-info."
        ),
    }


def safe_sshd_config_test() -> Tuple[bool, str]:
    """Run sshd -t on the local host. Does not modify config."""
    sshd = shutil.which("sshd")
    if not sshd:
        return False, "sshd binary not found"
    try:
        r = _run([sshd, "-t"], timeout=5)
        if r.returncode == 0:
            return True, "sshd -t OK"
        return False, (r.stderr or r.stdout or "sshd -t failed")[:300]
    except Exception as e:
        return False, str(e)


def local_service_status() -> Dict[str, Any]:
    """Local host OpenSSH status for doctor."""
    det = detect_sshd_service()
    ok, detail = safe_sshd_config_test()
    det["config_test_ok"] = ok
    det["config_test_detail"] = detail
    return det
