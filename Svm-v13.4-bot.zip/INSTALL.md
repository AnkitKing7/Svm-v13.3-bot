# Install

1. `sudo bash install.sh` — dependencies, backup, venv, systemd, firewall, `svm` CLI.
2. `sudo bash install.sh --configure` — Discord token, gateways, IP pool, ports.
3. `sudo bash install.sh ai-install` — AI wizard (endpoint, model, streaming, sandbox, status channel). Models are never downloaded without a confirmation.
4. `sudo bash install.sh doctor` / `ai-doctor` — verify everything.

Rollback: `sudo bash install.sh --rollback`.


## V13.4 - fully automatic install / upgrade

```bash
sudo bash install.sh upgrade            # no questions; LocalAI skipped; LXD installed + 90GiB pool auto-init
sudo bash install.sh upgrade --with-ai  # also install LocalAI (Docker)
sudo bash install.sh --lxd-disk=120     # different pool size (GiB)
sudo bash install.sh lxd-status         # show pools / network / saved .env values
```
