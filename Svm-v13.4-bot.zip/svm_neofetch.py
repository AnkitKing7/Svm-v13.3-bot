"""
SVM V14 — Neofetch-style VPS status card (SVG + optional PNG)
Made by AnkitCoder.

Does not require neofetch binary. Builds card from structured facts.
If neofetch is installed on the host, optional capture can enrich fields.
"""
from __future__ import annotations

import shutil
import subprocess
from typing import Any, Dict, Optional, Tuple


def try_host_neofetch() -> Dict[str, str]:
    if not shutil.which("neofetch"):
        return {}
    try:
        r = subprocess.run(
            ["neofetch", "--stdout"],
            capture_output=True, text=True, timeout=8,
        )
        out = {}
        for line in (r.stdout or "").splitlines():
            if ":" in line:
                k, _, v = line.partition(":")
                out[k.strip().lower()] = v.strip()
        return out
    except Exception:
        return {}


def build_svg(meta: Dict[str, Any]) -> str:
    name = str(meta.get("name") or "vps")[:40]
    os_ = str(meta.get("os") or "Linux")[:40]
    host = str(meta.get("host") or "—")[:40]
    ram = str(meta.get("ram") or "—")
    cpu = str(meta.get("cpu") or "—")
    disk = str(meta.get("disk") or "—")
    status = str(meta.get("status") or "unknown")[:20]
    color = "#22c55e" if status.lower() in ("running", "active", "online") else "#f59e0b"
    rows = [
        ("OS", os_),
        ("Host", host),
        ("RAM", ram),
        ("CPU", cpu),
        ("Disk", disk),
        ("Status", status),
    ]
    y = 100
    body = ""
    for lab, val in rows:
        body += f'<text x="28" y="{y}" fill="#94a3b8" font-size="14" font-family="DejaVu Sans,sans-serif">{lab}</text>'
        body += f'<text x="140" y="{y}" fill="#e2e8f0" font-size="14" font-family="DejaVu Sans,sans-serif" font-weight="600">{val}</text>'
        y += 28
    h = y + 36
    return f'''<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="520" height="{h}" viewBox="0 0 520 {h}">
  <rect width="520" height="{h}" rx="16" fill="#0f172a"/>
  <rect x="0" y="0" width="6" height="{h}" fill="{color}"/>
  <text x="28" y="40" fill="#f8fafc" font-size="22" font-family="DejaVu Sans,sans-serif" font-weight="700">{name}</text>
  <text x="28" y="64" fill="#64748b" font-size="12" font-family="DejaVu Sans,sans-serif">SVM status card · AnkitCoder</text>
  <circle cx="480" cy="36" r="10" fill="{color}"/>
  {body}
  <text x="28" y="{h-14}" fill="#475569" font-size="11" font-family="DejaVu Sans,sans-serif">neofetch-style · not proof of external reachability</text>
</svg>
'''


def svg_to_png_bytes(svg: str) -> Optional[bytes]:
    try:
        import cairosvg
        return cairosvg.svg2png(bytestring=svg.encode("utf-8"), output_width=1040)
    except Exception:
        pass
    try:
        from PIL import Image, ImageDraw, ImageFont
        import io
        img = Image.new("RGB", (1040, 560), (15, 23, 42))
        d = ImageDraw.Draw(img)
        d.rectangle([0, 0, 12, 560], fill=(34, 197, 94))
        try:
            font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 28)
            font2 = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 20)
        except Exception:
            font = font2 = ImageFont.load_default()
        d.text((40, 30), "SVM VPS Card", fill=(248, 250, 252), font=font)
        d.text((40, 90), "PNG fallback renderer", fill=(148, 163, 184), font=font2)
        buf = io.BytesIO()
        img.save(buf, format="PNG")
        return buf.getvalue()
    except Exception:
        return None


def build_vps_card(meta: Dict[str, Any]) -> Tuple[str, Optional[bytes]]:
    host_info = try_host_neofetch()
    if host_info and not meta.get("os"):
        meta = dict(meta)
        meta["os"] = host_info.get("os") or host_info.get("kernel") or meta.get("os")
    svg = build_svg(meta)
    png = svg_to_png_bytes(svg)
    return svg, png
