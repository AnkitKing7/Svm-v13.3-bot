"""
SVM V14 — Automatic host IP discovery → ips.txt / ips.json + pool sync
Made by AnkitCoder.

Read-only by default. Never invents public ownership. Never stores secrets.
Atomic writes + timestamped backups.
"""
from __future__ import annotations

import json
import logging
import os
import socket
import tempfile
import threading
import time
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

logger = logging.getLogger("svm.ip_discovery")

_FILE_LOCK = threading.Lock()

DEFAULT_IPS_TXT = os.getenv("SVM_IPS_TXT", "ips.txt")
DEFAULT_IPS_JSON = os.getenv("SVM_IPS_JSON", "ips.json")
EGRESS_CHECK_URL = os.getenv("SVM_EGRESS_CHECK_URL", "").strip()  # optional, e.g. https://ifconfig.me/ip


@dataclass
class DiscoveredAddr:
    address: str
    family: str  # inet|inet6
    prefix: Optional[int] = None
    ifname: str = ""
    classification: str = "unverified"
    source: str = "host"  # host|egress|provider|manual|db
    verification: str = "unverified"  # unverified|observed|provider_confirmed|allocated|reserved
    notes: str = ""
    detected_at: str = ""

    def as_dict(self) -> Dict[str, Any]:
        return asdict(self)


def _utc_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _classify(addr: str, family: str = "inet") -> str:
    try:
        from svm_topology import classify_ipv4
    except ImportError:
        classify_ipv4 = None  # type: ignore
    if family == "inet6":
        try:
            import ipaddress
            ip = ipaddress.ip_address(addr)
            if ip.is_loopback:
                return "loopback"
            if ip.is_link_local:
                return "link-local"
            if ip.is_private:  # unique local often
                return "unique-local"
            if ip.is_global:
                return "public-candidate-v6"
            return "other-v6"
        except Exception:
            return "invalid"
    if classify_ipv4:
        return classify_ipv4(addr)
    return "unverified"


def discover_host_addresses() -> List[DiscoveredAddr]:
    """Read local interfaces via ip -j; graceful if missing."""
    out: List[DiscoveredAddr] = []
    now = _utc_now()
    try:
        from svm_topology import _ip_json
        data = _ip_json(["address"])
    except Exception as e:
        logger.warning("ip address discovery failed: %s", e)
        data = []
    for iface in data or []:
        ifname = iface.get("ifname") or ""
        for info in iface.get("addr_info") or []:
            family = info.get("family")
            if family not in ("inet", "inet6"):
                continue
            local = info.get("local")
            if not local:
                continue
            cls = _classify(local, family)
            ver = "observed" if cls not in ("invalid",) else "unverified"
            out.append(DiscoveredAddr(
                address=local,
                family=family,
                prefix=info.get("prefixlen"),
                ifname=ifname,
                classification=cls,
                source="host",
                verification=ver,
                detected_at=now,
            ))
    return out


def discover_egress_ip(timeout: float = 4.0) -> Optional[DiscoveredAddr]:
    """Optional outbound public IP observation — NOT ownership proof."""
    url = EGRESS_CHECK_URL
    if not url:
        return None
    try:
        import urllib.request
        req = urllib.request.Request(url, headers={"User-Agent": "SVM-V14-Discovery/AnkitCoder"})
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            text = resp.read().decode().strip().split()[0]
        if not text:
            return None
        fam = "inet6" if ":" in text else "inet"
        return DiscoveredAddr(
            address=text,
            family=fam,
            classification=_classify(text, fam),
            source="egress",
            verification="observed",
            notes="egress observation only — not ownership proof",
            detected_at=_utc_now(),
        )
    except Exception as e:
        logger.info("egress check skipped/failed: %s", e)
        return None


def merge_inventory(
    discovered: List[DiscoveredAddr],
    existing: Optional[List[Dict[str, Any]]] = None,
    allocated: Optional[Set[str]] = None,
    reserved: Optional[Set[str]] = None,
) -> List[DiscoveredAddr]:
    by_key: Dict[Tuple[str, str], DiscoveredAddr] = {}
    for d in discovered:
        by_key[(d.address, d.family)] = d
    for row in existing or []:
        addr = str(row.get("address") or "")
        fam = str(row.get("family") or "inet")
        if not addr:
            continue
        key = (addr, fam)
        if key not in by_key:
            by_key[key] = DiscoveredAddr(
                address=addr,
                family=fam,
                prefix=row.get("prefix"),
                ifname=str(row.get("ifname") or ""),
                classification=str(row.get("classification") or "unverified"),
                source=str(row.get("source") or "manual"),
                verification=str(row.get("verification") or "unverified"),
                notes=str(row.get("notes") or "preserved from previous inventory"),
                detected_at=str(row.get("detected_at") or _utc_now()),
            )
    allocated = allocated or set()
    reserved = reserved or set()
    for key, d in by_key.items():
        if d.address in allocated:
            d.verification = "allocated"
            d.classification = d.classification if d.classification != "unverified" else "allocated"
        elif d.address in reserved:
            d.verification = "reserved"
    return sorted(by_key.values(), key=lambda x: (x.family, x.classification, x.address))


def _sections(addrs: List[DiscoveredAddr]) -> Dict[str, List[DiscoveredAddr]]:
    sec: Dict[str, List[DiscoveredAddr]] = {
        "HOST_ADDRESSES": [],
        "PRIVATE_IPS": [],
        "PUBLIC_CANDIDATES": [],
        "PROVIDER_CONFIRMED_PUBLIC_IPS": [],
        "OBSERVED_EGRESS_IPS": [],
        "ALLOCATED_IPS": [],
        "RESERVED_IPS": [],
        "UNVERIFIED_IPS": [],
        "LOOPBACK": [],
        "CGNAT_OR_SHARED": [],
        "IPV6": [],
    }
    for a in addrs:
        if a.family == "inet6":
            sec["IPV6"].append(a)
        if a.classification == "loopback":
            sec["LOOPBACK"].append(a)
        elif a.classification == "cgnat":
            sec["CGNAT_OR_SHARED"].append(a)
        elif a.classification == "private":
            sec["PRIVATE_IPS"].append(a)
        elif a.classification in ("public",) or a.classification.startswith("public"):
            if a.verification == "provider_confirmed":
                sec["PROVIDER_CONFIRMED_PUBLIC_IPS"].append(a)
            else:
                sec["PUBLIC_CANDIDATES"].append(a)
        elif a.verification == "unverified":
            sec["UNVERIFIED_IPS"].append(a)
        if a.source == "host":
            sec["HOST_ADDRESSES"].append(a)
        if a.source == "egress":
            sec["OBSERVED_EGRESS_IPS"].append(a)
        if a.verification == "allocated":
            sec["ALLOCATED_IPS"].append(a)
        if a.verification == "reserved":
            sec["RESERVED_IPS"].append(a)
    return sec


def render_ips_txt(addrs: List[DiscoveredAddr], hostname: str = "") -> str:
    host = hostname or socket.gethostname()
    lines = [
        "# SVM Automatic IP Inventory",
        f"# Generated: {_utc_now()}",
        f"# Host: {host}",
        "# NOTE: Presence here is NOT proof of public ownership or inbound reachability.",
        "",
    ]
    for name, group in _sections(addrs).items():
        lines.append(f"[{name}]")
        if not group:
            lines.append("# (none)")
        else:
            seen = set()
            for a in group:
                if a.address in seen:
                    continue
                seen.add(a.address)
                extra = f"  # if={a.ifname} class={a.classification} src={a.source} ver={a.verification}"
                lines.append(f"{a.address}{extra}")
        lines.append("")
    return "\n".join(lines) + "\n"


def write_inventory(
    addrs: List[DiscoveredAddr],
    *,
    base_dir: str = ".",
    ips_txt: str = DEFAULT_IPS_TXT,
    ips_json: str = DEFAULT_IPS_JSON,
) -> Dict[str, Any]:
    """Atomic write of ips.txt + ips.json with backup."""
    base = Path(base_dir)
    base.mkdir(parents=True, exist_ok=True)
    txt_path = base / ips_txt
    json_path = base / ips_json
    hostname = socket.gethostname()
    payload = {
        "generated_at": _utc_now(),
        "hostname": hostname,
        "count": len(addrs),
        "addresses": [a.as_dict() for a in addrs],
        "counts_by_class": {},
        "note": "Not proof of public ownership or inbound reachability",
    }
    for a in addrs:
        payload["counts_by_class"][a.classification] = payload["counts_by_class"].get(a.classification, 0) + 1

    with _FILE_LOCK:
        for path, content in (
            (txt_path, render_ips_txt(addrs, hostname)),
            (json_path, json.dumps(payload, indent=2) + "\n"),
        ):
            if path.exists():
                bak = path.with_suffix(path.suffix + f".bak.{int(time.time())}")
                try:
                    bak.write_bytes(path.read_bytes())
                except Exception as e:
                    logger.warning("backup failed %s: %s", path, e)
            fd, tmp = tempfile.mkstemp(dir=str(base), prefix=".ips-", suffix=".tmp")
            try:
                with os.fdopen(fd, "w", encoding="utf-8") as f:
                    f.write(content)
                os.chmod(tmp, 0o640)
                os.replace(tmp, path)
            finally:
                if os.path.exists(tmp):
                    try:
                        os.unlink(tmp)
                    except Exception:
                        pass
    return {
        "ok": True,
        "ips_txt": str(txt_path),
        "ips_json": str(json_path),
        "count": len(addrs),
        "counts_by_class": payload["counts_by_class"],
    }


def load_existing_json(path: str) -> List[Dict[str, Any]]:
    p = Path(path)
    if not p.exists():
        return []
    try:
        data = json.loads(p.read_text())
        return list(data.get("addresses") or [])
    except Exception:
        return []


def run_discovery(
    *,
    base_dir: str = ".",
    include_egress: bool = False,
    allocated: Optional[Set[str]] = None,
    reserved: Optional[Set[str]] = None,
) -> Dict[str, Any]:
    """Full read-only discovery + write inventory files."""
    discovered = discover_host_addresses()
    if include_egress:
        eg = discover_egress_ip()
        if eg:
            discovered.append(eg)
    existing = load_existing_json(str(Path(base_dir) / DEFAULT_IPS_JSON))
    merged = merge_inventory(discovered, existing, allocated=allocated, reserved=reserved)
    written = write_inventory(merged, base_dir=base_dir)
    written["addresses"] = [a.as_dict() for a in merged]
    written["topology_hint"] = None
    try:
        from svm_topology import detect_capabilities
        written["topology_hint"] = detect_capabilities().as_dict()
    except Exception as e:
        written["topology_error"] = str(e)
    return written


def sync_pools_from_discovery(conn, inventory: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Soft-sync discovered addresses into IPAM tables if schema present.
    Does NOT delete ALLOCATED rows. Idempotent inserts for candidates.
    """
    try:
        from svm_ipam import ensure_schema
        ensure_schema(conn)
    except Exception as e:
        return {"ok": False, "error": f"schema: {e}"}
    added = 0
    skipped = 0
    for row in inventory:
        addr = row.get("address")
        if not addr or row.get("family") != "inet":
            skipped += 1
            continue
        cls = row.get("classification") or ""
        # only track private and public-looking candidates; never auto-mark public as allocatable
        pool = "PRIVATE" if cls == "private" else ("PUBLIC_CANDIDATE" if cls == "public" else "DISCOVERED")
        try:
            conn.execute(
                "INSERT OR IGNORE INTO ipam_addresses(address, pool, status, meta_json) VALUES(?,?,?,?)",
                (addr, pool, "available" if pool != "PUBLIC_CANDIDATE" else "reserved",
                 json.dumps({"source": row.get("source"), "class": cls, "verification": row.get("verification")})),
            )
            added += 1
        except Exception:
            # flexible schema — try alternate column sets
            try:
                conn.execute(
                    "INSERT OR IGNORE INTO ip_addresses(address, status) VALUES(?,?)",
                    (addr, "discovered"),
                )
                added += 1
            except Exception:
                skipped += 1
    try:
        conn.commit()
    except Exception:
        pass
    return {"ok": True, "attempted": len(inventory), "added_or_ignored": added, "skipped": skipped}
