# AUDIT V14 — SVM Advanced AI V13 → V14 Networking Engine

**Auditor role:** Senior Linux networking / Python / security  
**Date:** 2026-10-24  
**Source tree:** SVM Advanced AI V13 (AnkitCoder)

## Files inspected

| File | Size (approx) | Notes |
|------|---------------|--------|
| bot.py | 757 KB | 128 Discord commands; ipool/nat/ports/sshfix/filemanager present |
| svm12.py | 47 KB | Payments, OS catalog, migrations core |
| svm_ipam.py | 23 KB | Lifecycle states; BindMode record/routed/nat/portfwd/bridged |
| svm_net.py | 14 KB | Backend detect; iptables rule build; dry-run |
| svm_ssh.py | 10 KB | SSH diagnose states |
| svm_dns.py | 11 KB | Hostname + CF adapter |
| svm_files.py | 6 KB | SFTP FM |
| svm_tools.py | 9 KB | 9 registered tools (honest) |
| install.sh | 69 KB | upgrade/backup/test/doctor |
| .env.example | 4 KB | IPAM/DNS/SSH keys |
| tests/* | — | IPAM concurrent, net dry-run, DNS, integration |

## Findings (verified against code)

| ID | Finding | Severity | Evidence |
|----|---------|----------|----------|
| F1 | ACTIVE vs RECORDED health exists in IPAM but bot/UI may still treat DB rows loosely | Medium | AddrStatus/Health enums in svm_ipam.py |
| F2 | Routed / 1:1 NAT correctly refused without ownership in unit tests; operator topology confirm incomplete | Medium | svm_net.apply_mapping nat path |
| F3 | No explicit topology classifier (DIRECT_PUBLIC / UPSTREAM_NAT / CGNAT / …) | High for V14 goals | Missing module pre-V14 |
| F4 | WireGuard tunnel mode absent | Info → V14 Mode D | — |
| F5 | External verification states not first-class in schema | Medium | Health enum limited |
| F6 | Port-forward path is primary production path for /32 hosts | By design | auto_ipv4 → portfwd |
| F7 | Duplicate command registration mitigated by remove_command layers | Low | bot.py |
| F8 | Real public IP external reachability not testable in sandbox | Blocked | 172.16.0.0/24 only |

## Architecture decisions for V14

1. Add `svm_topology.py` for capability + topology classification (assessment, not invented facts).
2. Add `svm_map.py` orchestration for modes A–E with dry-run / apply / verify / rollback hooks.
3. Extend verification labels: RECORDED → INSTALLED → LOCAL_VERIFIED → EXTERNAL_VERIFIED.
4. Optional WireGuard config *generator* (no hard-coded keys); apply only with explicit flag.
5. Preserve V13 tables; additive migrations `14001+`.
6. Do not flush firewall; only SVM-tagged rules.

## Out of scope / not claimed

- Live external verification from this sandbox.
- Automatic purchase of provider public IPs.
- Flushing host firewall or replacing default route.
EOF
echo OK
