"""
SVM V14 — Host topology & capability assessment
Made by AnkitCoder.

Classifications are *assessments* derived from observed interfaces, routes,
forwarding, and optional operator confirmation — never invented gateways or MACs.
"""
from __future__ import annotations

import ipaddress
import json
import logging
import os
import shutil
import subprocess
from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Any, Dict, List, Optional

logger = logging.getLogger("svm.topology")


class TopologyClass(str, Enum):
    DIRECT_PUBLIC = "DIRECT_PUBLIC"
    UPSTREAM_NAT = "UPSTREAM_NAT"
    CGNAT_OR_SHARED_SPACE = "CGNAT_OR_SHARED_SPACE"
    PROVIDER_ROUTED = "PROVIDER_ROUTED"
    PRIVATE_ONLY = "PRIVATE_ONLY"
    UNKNOWN = "UNKNOWN"


class MapVerifyState(str, Enum):
    RECORDED = "RECORDED"
    INSTALLED = "INSTALLED"
    LOCAL_VERIFIED = "LOCAL_VERIFIED"
    EXTERNAL_VERIFIED = "EXTERNAL_VERIFIED"
    FAILED = "FAILED"
    UNKNOWN = "UNKNOWN"
    DRIFT = "DRIFT"
    ROLLING_BACK = "ROLLING_BACK"
    QUARANTINED = "QUARANTINED"


def _run(argv: List[str], timeout: int = 10) -> subprocess.CompletedProcess:
    return subprocess.run(list(argv), capture_output=True, text=True, timeout=timeout)


def _ip_json(args: List[str]) -> Any:
    try:
        r = _run(["ip", "-j"] + args)
        if r.returncode == 0 and r.stdout.strip():
            return json.loads(r.stdout)
    except Exception as e:
        logger.debug("ip -j %s failed: %s", args, e)
    return []


@dataclass
class CapabilityReport:
    kernel: str = ""
    distro: str = ""
    forwarding_v4: bool = False
    backend: str = "none"  # nftables|iptables|none
    has_bridge: bool = False
    has_wireguard: bool = False
    interfaces: List[Dict[str, Any]] = field(default_factory=list)
    global_v4: List[str] = field(default_factory=list)
    private_v4: List[str] = field(default_factory=list)
    cgnat_v4: List[str] = field(default_factory=list)
    public_v4: List[str] = field(default_factory=list)
    default_gw: Optional[str] = None
    default_dev: Optional[str] = None
    topology: str = TopologyClass.UNKNOWN.value
    topology_reason: str = ""
    operator_override: str = ""  # explicit confirm from env/admin
    supported_modes: List[str] = field(default_factory=list)
    notes: List[str] = field(default_factory=list)

    def as_dict(self) -> Dict[str, Any]:
        return asdict(self)


def classify_ipv4(addr: str) -> str:
    try:
        ip = ipaddress.ip_address(addr)
    except ValueError:
        return "invalid"
    if ip.version != 4:
        return "non-v4"
    if ip.is_loopback:
        return "loopback"
    if ip.is_link_local:
        return "link-local"
    if ip.is_multicast:
        return "multicast"
    if ip in ipaddress.ip_network("100.64.0.0/10"):
        return "cgnat"
    if ip.is_private:
        return "private"
    if ip.is_global:
        return "public"
    if ip.is_reserved or ip.is_unspecified:
        return "reserved"
    return "other"


def detect_capabilities(*, operator_topology: str = "") -> CapabilityReport:
    rep = CapabilityReport()
    try:
        r = _run(["uname", "-r"])
        rep.kernel = (r.stdout or "").strip()
    except Exception:
        pass
    try:
        if os.path.exists("/etc/os-release"):
            data = open("/etc/os-release").read()
            for line in data.splitlines():
                if line.startswith("PRETTY_NAME="):
                    rep.distro = line.split("=", 1)[1].strip().strip('"')
    except Exception:
        pass

    try:
        with open("/proc/sys/net/ipv4/ip_forward") as f:
            rep.forwarding_v4 = f.read().strip() == "1"
    except Exception:
        pass

    # backend
    if shutil.which("nft"):
        try:
            if _run(["nft", "list", "ruleset"], timeout=8).returncode == 0:
                rep.backend = "nftables"
        except Exception:
            pass
    if rep.backend == "none" and shutil.which("iptables"):
        try:
            if _run(["iptables", "-L", "-n"], timeout=8).returncode == 0:
                rep.backend = "iptables"
        except Exception:
            pass

    rep.has_wireguard = bool(shutil.which("wg") or os.path.exists("/sys/module/wireguard"))

    addrs = _ip_json(["address"])
    for iface in addrs or []:
        name = iface.get("ifname") or ""
        for info in iface.get("addr_info") or []:
            if info.get("family") != "inet":
                continue
            local = info.get("local")
            if not local:
                continue
            entry = {
                "ifname": name,
                "address": local,
                "prefix": info.get("prefixlen"),
                "scope": info.get("scope"),
                "class": classify_ipv4(local),
            }
            rep.interfaces.append(entry)
            cls = entry["class"]
            if cls == "public":
                rep.public_v4.append(local)
            elif cls == "private":
                rep.private_v4.append(local)
            elif cls == "cgnat":
                rep.cgnat_v4.append(local)
            if info.get("scope") == "global":
                rep.global_v4.append(local)

    routes = _ip_json(["route"])
    for rt in routes or []:
        if rt.get("dst") in ("default", "0.0.0.0/0"):
            rep.default_gw = rt.get("gateway")
            rep.default_dev = rt.get("dev")
            break

    try:
        br = _ip_json(["link", "show", "type", "bridge"])
        rep.has_bridge = bool(br)
    except Exception:
        pass

    # operator override
    override = (operator_topology or os.getenv("SVM_TOPOLOGY_OVERRIDE") or "").strip().upper()
    if override in {t.value for t in TopologyClass}:
        rep.operator_override = override
        rep.topology = override
        rep.topology_reason = "operator override (SVM_TOPOLOGY_OVERRIDE or argument)"
    else:
        rep.topology, rep.topology_reason = _infer_topology(rep)

    rep.supported_modes = _modes_for_topology(rep.topology, rep)
    if not rep.forwarding_v4 and any(m in rep.supported_modes for m in ("portfwd", "nat")):
        rep.notes.append("ip_forward=0; portfwd/nat need forwarding enabled by operator")
    if rep.backend == "none":
        rep.notes.append("No firewall backend detected; only record mode is safe")
    return rep


def _infer_topology(rep: CapabilityReport) -> tuple:
    if rep.cgnat_v4 and not rep.public_v4:
        return TopologyClass.CGNAT_OR_SHARED_SPACE.value, "observed 100.64.0.0/10 address, no global public"
    if rep.public_v4:
        # single public often still upstream NAT at hypervisor — do not over-claim DIRECT
        if len(rep.public_v4) == 1:
            return (
                TopologyClass.UPSTREAM_NAT.value,
                "single global public/private address observed; often hypervisor NAT — confirm before 1:1",
            )
        return TopologyClass.DIRECT_PUBLIC.value, "multiple public addresses observed on host"
    if rep.private_v4 and not rep.public_v4:
        return TopologyClass.PRIVATE_ONLY.value, "only RFC1918 addresses on host interfaces"
    return TopologyClass.UNKNOWN.value, "insufficient address/route evidence"


def _modes_for_topology(topo: str, rep: CapabilityReport) -> List[str]:
    modes = ["record"]
    if rep.backend == "none":
        return modes
    if topo in (
        TopologyClass.DIRECT_PUBLIC.value,
        TopologyClass.UPSTREAM_NAT.value,
        TopologyClass.PROVIDER_ROUTED.value,
        TopologyClass.UNKNOWN.value,
    ):
        modes.append("portfwd")
    if topo in (TopologyClass.DIRECT_PUBLIC.value, TopologyClass.PROVIDER_ROUTED.value):
        modes.append("nat")
        modes.append("routed")
    if topo == TopologyClass.PROVIDER_ROUTED.value:
        if "routed" not in modes:
            modes.append("routed")
    modes.append("wireguard")  # optional overlay; never equals public IPv4
    return modes


def redact_secrets(obj: Any) -> Any:
    """Strip obvious secret-looking keys from nested dicts for safe diagnostics."""
    SECRET_KEYS = {"password", "token", "api_key", "secret", "private_key", "authorized_keys"}
    if isinstance(obj, dict):
        out = {}
        for k, v in obj.items():
            if str(k).lower() in SECRET_KEYS or "password" in str(k).lower() or "token" in str(k).lower():
                out[k] = "***REDACTED***"
            else:
                out[k] = redact_secrets(v)
        return out
    if isinstance(obj, list):
        return [redact_secrets(x) for x in obj]
    return obj
