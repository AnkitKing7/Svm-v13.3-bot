# KVM paid auto-create (AnkitCoder)

## Flow
1. Host: `/dev/kvm` + libvirt (`sudo bash install.sh --with-virt` then `!kvm-install confirm`)
2. Place cloud-init qcow2 at `KVM_BASE_IMAGE` (e.g. Ubuntu cloud image)
3. User: `!kvm-buy` or `!buy kvm-starter` → UPI/Razorpay (existing rails)
4. Webhook marks order **paid** → `v112v_auto_provision_order` → `KvmProvider.create_instance`
5. Progress job 20% → 75% → 100%; DM with domain + root password

## Env
```
KVM_ADDON_PRICE_INR=10
KVM_BASE_IMAGE=/var/lib/svm/images/ubuntu-22.04-cloudimg.qcow2
KVM_VM_DIR=/var/lib/svm/vms
KVM_NETWORK=default
```

## Notes
- Default libvirt network is often **private NAT** — public SSH needs portfwd/IPAM.
- Without `KVM_BASE_IMAGE` file, payment stays paid and provision fails with a clear error (retry after image is placed).
