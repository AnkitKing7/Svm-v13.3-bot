"""
SVM V14 — Full KVM lifecycle (libvirt / virsh / virt-install)
Made by AnkitCoder.

Wraps svm12.KvmProvider with list/start/stop/reboot/delete/info/images helpers.
Never invents public IP reachability. Default libvirt network is often private NAT.
"""
from __future__ import annotations

import logging
import os
import re
import secrets
import shutil
from typing import Any, Dict, List, Optional

logger = logging.getLogger("svm.kvm")

NAME_RE = re.compile(r"^[a-z0-9][a-z0-9\-]{0,40}$")


def _provider():
    import svm12
    return svm12.KvmProvider()


def health() -> Dict[str, Any]:
    import svm12
    return svm12.detect_kvm()


def require_ready() -> Dict[str, Any]:
    h = health()
    if not h.get("ready"):
        raise RuntimeError("KVM not ready: missing " + ", ".join(h.get("missing") or []))
    return h


def list_images(image_dir: Optional[str] = None) -> List[Dict[str, str]]:
    base = image_dir or os.getenv("KVM_IMAGE_DIR", "/var/lib/svm/images")
    out = []
    try:
        for f in sorted(os.listdir(base)):
            if f.endswith((".qcow2", ".img", ".raw")):
                path = os.path.join(base, f)
                try:
                    sz = os.path.getsize(path)
                except OSError:
                    sz = 0
                out.append({"name": f, "path": path, "size_bytes": sz})
    except OSError as e:
        logger.warning("list_images: %s", e)
    return out


def resolve_base_image(explicit: Optional[str] = None) -> str:
    if explicit and os.path.isfile(explicit):
        return explicit
    env = (os.getenv("KVM_BASE_IMAGE") or "").strip()
    if env and os.path.isfile(env):
        return env
    imgs = list_images()
    if imgs:
        return imgs[0]["path"]
    raise RuntimeError(
        "No KVM base image. Set KVM_BASE_IMAGE or place a qcow2 in "
        f"{os.getenv('KVM_IMAGE_DIR', '/var/lib/svm/images')}"
    )


def list_vms() -> List[Dict[str, Any]]:
    prov = _provider()
    names = prov.list_instances()
    out = []
    for row in names:
        name = row.get("name") if isinstance(row, dict) else str(row)
        if not name:
            continue
        inst = prov.get_instance(name) or {"name": name, "status": "unknown", "type": "kvm", "addresses": []}
        out.append(inst)
    return out


def get_vm(name: str) -> Optional[Dict[str, Any]]:
    if not NAME_RE.match(name or ""):
        raise ValueError("invalid VM name")
    return _provider().get_instance(name)


def create_vm(
    name: str,
    *,
    cpu: int = 1,
    ram_gb: int = 1,
    disk_gb: int = 10,
    root_password: Optional[str] = None,
    base_image: Optional[str] = None,
    network: Optional[str] = None,
    ssh_key: Optional[str] = None,
) -> Dict[str, Any]:
    if not NAME_RE.match(name or ""):
        raise ValueError("invalid VM name (lowercase alnum/hyphen, max 41)")
    require_ready()
    base = resolve_base_image(base_image)
    password = root_password or secrets.token_urlsafe(12)
    workdir = os.getenv("KVM_VM_DIR", "/var/lib/svm/vms")
    net = network or os.getenv("KVM_NETWORK", "default")
    key = ssh_key if ssh_key is not None else os.getenv("KVM_SSH_PUBKEY", "")
    prov = _provider()
    inst = prov.create_instance(
        name, base, int(cpu), int(ram_gb), int(disk_gb), password,
        workdir=workdir, network=net, ssh_key=key or "",
    )
    return {
        "instance": inst,
        "root_password": password,
        "base_image": base,
        "network": net,
        "workdir": os.path.join(workdir, name),
    }


def start_vm(name: str) -> bool:
    return bool(_provider().start_instance(name))


def stop_vm(name: str) -> bool:
    return bool(_provider().stop_instance(name))


def reboot_vm(name: str) -> bool:
    return bool(_provider().restart_instance(name))


def delete_vm(name: str) -> bool:
    return bool(_provider().delete_instance(name))


def console_hint(name: str) -> str:
    return _provider().get_console(name)


def ensure_dirs() -> None:
    for d in (
        os.getenv("KVM_IMAGE_DIR", "/var/lib/svm/images"),
        os.getenv("KVM_VM_DIR", "/var/lib/svm/vms"),
    ):
        try:
            os.makedirs(d, mode=0o755, exist_ok=True)
        except OSError as e:
            logger.warning("mkdir %s: %s", d, e)


def summary() -> Dict[str, Any]:
    h = health()
    return {
        "health": h,
        "images": list_images(),
        "vms": list_vms() if h.get("ready") else [],
        "base_image_env": os.getenv("KVM_BASE_IMAGE", ""),
        "image_dir": os.getenv("KVM_IMAGE_DIR", "/var/lib/svm/images"),
        "vm_dir": os.getenv("KVM_VM_DIR", "/var/lib/svm/vms"),
        "network": os.getenv("KVM_NETWORK", "default"),
        "note": "Libvirt default network is often private NAT; public access needs portfwd/IPAM.",
    }
