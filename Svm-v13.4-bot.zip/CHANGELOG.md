# V13.4 (fix release)

- **FIXED: `!create`, `!create-vps`, `!cv`, `!manage`, `!kvm-*`, `!neofetch`, `!vpsmap`, `!ipscan`, `!autopool`, ... did not answer (silent).**
  Cause: a "V13 command dedupe" loop at the bottom of `bot.py` (inside `__main__`, right before `bot.run()`) called
  `bot.remove_command()` on those commands after they were registered. Unknown commands are ignored by design => silence. Loop removed.
- **FIXED: `!plans`, `!buy`, `!orders`, `!billing`, `!ports` were never registered** (their `@bot.command` lines had been commented out
  as `V14_DEDUPE` while the older versions were already removed). Decorators restored; `!ports`, `!myorders`, `!renew` are no longer removed.
- `on_command_error` rewritten: never silent. Unwraps the real exception, logs a traceback, replies in channel (DM fallback),
  shows usage for missing arguments, and suggests "Did you mean ...?" for typos.
- `!manage` / `!manage-shared` panel can no longer hang or crash: stats lookup has a timeout + fallback, missing VPS keys tolerated.
- **install.sh (V13.4):** `install` and `upgrade` are now fully automatic.
  - LocalAI is **skipped automatically** (no prompts, no multi-GB download). Opt in with `--with-ai`. If no LocalAI is reachable, `AI_ENABLED=false` is written so `!askai` does not show a broken state.
  - **LXD is installed and initialised automatically** (`lxd init --preseed`): storage pool `default`, **90 GiB** (btrfs loop pool; falls back to `dir` if the kernel lacks btrfs, free space is too small, or init fails), bridge `lxdbr0` (NAT, IPv4 auto). Saved to `/opt/svm/lxd-preseed.yaml` and to `.env` (`DEFAULT_STORAGE_POOL`, `LXD_POOL_SIZE_GB`, `LXD_BRIDGE`). An already-initialised LXD is never touched.
  - `upgrade` never asks questions (use `--interactive` to get them back).
  - New flags: `--with-ai`, `--skip-ai`, `--no-lxd`, `--lxd-disk=NN`, `--lxd-driver=btrfs|zfs|dir`, `--lxd-pool=NAME`, `--with-virt`; new commands `lxd-init`, `lxd-status`. (`--with-ai/--with-virt/--with-lxd` were documented before but rejected as "Unknown option".)

- New regression test: `tests/test_command_registry_v134.py` (+ `tests/fakecord_registry.py`, a discord.py-faithful command registry).
  Run: `python3 -m unittest tests.test_command_registry_v134 -v`

# Changelog

## V13.0 (2026-10-22) — SVM Advanced AI V13 — Made by AnkitCoder

### Added
- `svm_ipam.py`: unified IPAM with full lifecycle states, overlap detection, concurrent-safe allocation, health labels (RECORDED/INSTALLED/VERIFIED/DRIFT)
- `svm_net.py`: networking backend capability detection, dry-run apply, owned iptables comments (SVM-V13:…), diagnostic snapshot
- `svm_ssh.py`: structured SSH states, Termius/OpenSSH connection profiles, local sshd detection, auth test helpers
- Installer subcommands: `upgrade`, `backup`, `test`; pre-v13 timestamped backups; env key merge (never overwrite)
- Migration 13001 (additive IPAM columns + svm_schema_migrations)
- Unit tests: `tests/test_ipam_v13.py`, `tests/test_ssh_net_v13.py`
- `V13_UPGRADE.md` operational guide
- Configurable `BOT_OWNER_IMAGE_URL` / `BOT_BANNER_IMAGE_URL`

### Changed
- Default `BOT_VERSION=13.0`, `BOT_NAME=SVM Advanced AI V13`
- ACTIVE mappings require backend verification; DB-only stay RECORDED
- Honest capability reporting for LocalAI (unreachable → explicit fail, no silent wrong-model image gen)

### Preserved
- All V12 payment flows, port 5000 WebSSH/Admin, port 8787 webhooks
- Existing Discord commands and aliases
- Customer VPS records, orders, payments, port_forwards
- LXC provisioning path

### Not claimed / not tested on real host
- Public IPv4 end-to-end reachability
- Live SSH authentication against production VMs
- Provider-routed secondary public IPs without topology confirmation
