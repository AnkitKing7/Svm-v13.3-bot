"""V13.4 regression: commands must stay registered and must never fail silently.

Root cause fixed in V13.4: a "command dedupe" loop inside `if __name__ == "__main__":` called bot.remove_command() on
create / manage / kvm-* / neofetch / ... right before bot.run(), so those commands vanished (CommandNotFound is swallowed
=> the bot looked silent).  tests/_stubs.py's FakeBot hid this (no remove_command, silent overwrite), so this test uses
tests/fakecord_registry.py which behaves like discord.py (duplicate -> error, remove_command really removes).

Run:  python3 -m unittest tests.test_command_registry_v134 -v      (no discord.py / pytest needed)
"""
import asyncio, importlib.util, os, re, shutil, sys, tempfile, textwrap, unittest

HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
TMP = tempfile.mkdtemp(prefix="svm134-")
for f in os.listdir(ROOT):
    p = os.path.join(ROOT, f)
    if os.path.isfile(p):
        shutil.copy(p, TMP)
_old = os.getcwd(); os.chdir(TMP)
os.environ.update(DISCORD_TOKEN="x", MAIN_ADMIN_ID="111", ADMIN_WEB_PASSWORD="pw-test-123456")
import fakecord_registry as F  # noqa: E402
sys.path.insert(0, TMP)
_spec = importlib.util.spec_from_file_location("botmod134", os.path.join(TMP, "bot.py"))
m = importlib.util.module_from_spec(_spec); sys.modules["botmod134"] = m; _spec.loader.exec_module(m)
bot = m.bot; F._ERR["fn"] = m.on_command_error; bot.latency = 0.05
ADMIN, OWNER, FRIEND, OTHER = (F.FakeMember(i, n) for i, n in ((111, "admin"), (222, "owner"), (333, "friend"), (444, "other")))
for x in (ADMIN, OWNER, FRIEND, OTHER):
    F.MEMBERS[x.id] = x
SRC = open(os.path.join(ROOT, "bot.py"), encoding="utf-8").read()

REQUIRED = ["create", "create-vps", "cv", "createvps", "manage", "manage-shared", "ms", "list-shared", "share-user", "share-ruser",
            "kvm-create", "kvm-list", "kvm-start", "kvm-stop", "kvm-delete", "kvm-dev", "plans", "buy", "orders", "billing",
            "ports", "myorders", "renew", "payment-proof", "approve-order", "reject-order", "vpsinfo", "neofetch", "ipscan",
            "askai", "help", "myvps", "nat", "sshfix", "nodes"]


def run(coro):
    return asyncio.new_event_loop().run_until_complete(coro)


def say(ctx):
    return " ".join(f"{getattr(o.get('embed'), 'title', '')} {getattr(o.get('embed'), 'description', '')}" for o in ctx.out)


class Registry(unittest.TestCase):
    def test_required_commands_registered(self):
        self.assertEqual([n for n in REQUIRED if n not in bot.all_commands], [])

    def test_main_block_does_not_delete_commands(self):
        main = SRC[SRC.index('if __name__ == "__main__":'):]
        self.assertNotIn("remove_command", main, "__main__ must not remove commands before bot.run()")

    def test_unknown_command_is_not_registered_but_typo_gets_hint(self):
        ctx = run(F.dispatch(bot, "!creat", ADMIN))
        self.assertIn("create", say(ctx).lower())


class Dispatch(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        async def stats(c, n):
            return {"status": "running", "cpu": 1.0, "ram": {"used": 1, "total": 2, "pct": 50.0}, "disk": "1/2", "uptime": "1h"}
        m.get_container_stats = stats
        m.vps_data.clear()
        m.vps_data["222"] = [{"container_name": "svm-t-1", "node_id": 1, "ram": "2GB", "cpu": "1", "storage": "20GB", "config": "c",
                              "status": "running", "suspended": False, "shared_with": [], "os_version": "ubuntu:22.04"}]

    def replies(self, text, who):
        ctx = run(F.dispatch(bot, text, who)); self.assertTrue(ctx.out, f"{text!r} was SILENT"); return ctx

    def test_create(self):
        self.assertTrue(any(o.get("view") is not None for o in self.replies("!create 2 1 20 <@222> 30", ADMIN).out))
        self.assertIn("Access Denied", say(self.replies("!create 2 1 20 <@222> 30", OTHER)))
        self.assertIn("Missing", say(self.replies("!create 2 1", ADMIN)))

    def test_manage(self):
        self.assertTrue(any(o.get("view") is not None for o in self.replies("!manage", OWNER).out))
        self.assertIn("No VPS", say(self.replies("!manage", OTHER)))
        self.assertIn("Denied", say(self.replies("!manage <@222>", OTHER)))

    def test_manage_shared_flow(self):
        self.assertIn("Usage", say(self.replies("!manage-shared", FRIEND)))
        self.assertIn("Access Denied", say(self.replies("!manage-shared <@222> 1", FRIEND)))
        self.assertIn("Shared", say(self.replies("!share-user <@333> 1", OWNER)))
        self.assertTrue(any(o.get("view") is not None for o in self.replies("!manage-shared <@222> 1", FRIEND).out))
        self.assertTrue(any(o.get("view") is not None for o in self.replies("!ms <@222> 1", FRIEND).out))

    def test_manage_survives_hanging_stats(self):
        async def hang(c, n):
            await asyncio.sleep(3600)
        old, oldt = m.get_container_stats, m.safe_container_stats
        m.get_container_stats = hang
        async def quick(c, n, timeout=0.2):
            return await oldt(c, n, timeout=0.2)
        m.safe_container_stats = quick
        try:
            self.assertTrue(any(o.get("view") is not None for o in self.replies("!manage", OWNER).out))
        finally:
            m.get_container_stats, m.safe_container_stats = old, oldt


if __name__ == "__main__":
    unittest.main()
