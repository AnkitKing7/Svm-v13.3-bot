"""Faithful-enough discord.py command registry (duplicate detection + remove_command semantics)."""
import sys, os, inspect
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import _stubs  # noqa
from _stubs import Dummy, Embed
cm = sys.modules['discord.ext.commands']

class CommandRegistrationError(Exception): pass
class CommandNotFound(Exception): pass
cm.CommandRegistrationError = CommandRegistrationError
cm.CommandNotFound = CommandNotFound
for n in ('MissingRequiredArgument','BadArgument','CheckFailure','CommandError'):
    setattr(cm, n, type(n,(Exception,),{}))

class Command:
    async def __call__(self,ctx,*a,**k): return await self.callback(ctx,*a,**k)
    def __init__(self, f, name=None, aliases=(), hidden=False, **kw):
        self.callback=f; self.name=name or f.__name__; self.aliases=list(aliases or []); self.hidden=hidden
        self.help=(f.__doc__ or '').strip() or None; self.brief=None; self.checks=getattr(f,'__commands_checks__',[])
        self.qualified_name=self.name
        try: self.signature=' '.join(f'<{p}>' for p in list(inspect.signature(f).parameters)[1:])
        except Exception: self.signature=''

class Bot:
    def __init__(self,*a,**k):
        self.all_commands={}; self.loop=None; self.listeners=[]
    @property
    def commands(self):
        seen=[]; 
        for c in self.all_commands.values():
            if c not in seen: seen.append(c)
        return seen
    def add_command(self,c):
        for k in [c.name]+c.aliases:
            if k in self.all_commands:
                raise CommandRegistrationError(f"The command {k} is already an existing command or alias.")
        for k in [c.name]+c.aliases: self.all_commands[k]=c
    def remove_command(self,name):
        c=self.all_commands.pop(name,None)
        if c is None: return None
        for a in c.aliases: self.all_commands.pop(a,None)
        return c
    def get_command(self,n): return self.all_commands.get(n)
    def command(self,*a,**k):
        def deco(f):
            if isinstance(f,Command): c=f
            else: c=Command(f,name=k.get('name') or (a[0] if a else None),aliases=k.get('aliases'),hidden=k.get('hidden',False))
            self.add_command(c); return c  # real discord.py returns Command
        return deco
    hybrid_command=command
    def add_listener(self,f,name=None): self.listeners.append((name or f.__name__,f))
    def event(self,f): return f
    def __getattr__(self,n):
        if n.startswith('__'): raise AttributeError(n)
        return Dummy()
cm.Bot=Bot

# ---- more faithful pieces: command checks, ui.View component limits, Member/ctx, dispatcher ----
import asyncio, re, traceback
class CommandInvokeError(Exception):
    def __init__(self,e): super().__init__(str(e)); self.original=e
cm.CommandInvokeError=CommandInvokeError
def check(pred):
    def deco(f):
        if isinstance(f,Command): f.checks.append(pred); return f
        f.__dict__.setdefault('__commands_checks__',[]).append(pred); return f
    return deco
cm.check=check
cm.has_permissions=lambda **k: check(lambda ctx: True)

dm=sys.modules['discord']
class Forbidden(Exception): pass
class NotFound(Exception): pass
dm.Forbidden=Forbidden; dm.NotFound=NotFound
sys.modules['discord.errors'].LoginFailure=type('LoginFailure',(Exception,),{})

class Item:
    def __init__(self,*a,**k): self.row=k.get('row'); self.label=k.get('label'); self.callback=None; self.width=1; self.disabled=k.get('disabled',False)
class Button(Item): pass
class SelectOption:
    def __init__(self,label=None,value=None,description=None,**k):
        assert label and len(label)<=100, 'select label'; self.label=label; self.value=value
class Select(Item):
    def __init__(self,*a,options=None,**k):
        super().__init__(*a,**k); self.width=5; self.options=options or []; self.values=[]
        assert len(self.options)<=25, 'select max 25 options'
class View:
    def __init__(self,*a,timeout=180,**k): self.children=[]; self.timeout=timeout
    def add_item(self,item):
        if len(self.children)>=25: raise ValueError('maximum number of children exceeded')
        row=item.row
        if row is None:
            row=0
            while sum(c.width for c in self.children if c.row==row)+item.width>5: row+=1
            item.row=row
        if row>4: raise ValueError('row cannot exceed 4')
        if sum(c.width for c in self.children if c.row==row)+item.width>5: raise ValueError(f'item would not fit at row {row}')
        self.children.append(item); return self
    def clear_items(self): self.children=[]
    def remove_item(self,i): self.children.remove(i)
    def stop(self): pass
    async def on_timeout(self): pass
ui=sys.modules['discord.ui']; ui.View=View; ui.Button=Button; ui.Select=Select; ui.Modal=type('Modal',(View,),{}); ui.TextInput=Item
dm.SelectOption=SelectOption

class FakeMember:
    def __init__(self,id,name='user'): self.id=id; self.name=name; self.mention=f'<@{id}>'; self.bot=False; self.sent=[]
    async def send(self,*a,**k): self.sent.append((a,k)); return None
    def __str__(self): return self.name
class FakeMsg:
    def __init__(self,kw): self.kw=kw; self.attachments=[]
    async def edit(self,**k): self.kw.update(k)
    async def delete(self,**k): pass
class FakeCtx:
    def __init__(self,bot,author,content,cmd=None,invoked=None):
        self.bot=bot; self.author=author; self.command=cmd; self.invoked_with=invoked; self.out=[]
        self.message=types_ns(attachments=[],content=content,author=author); import datetime as _d; self.guild=types_ns(id=999,name='G',members=[],created_at=_d.datetime.now(),member_count=3,owner=None); self.channel=types_ns(id=1)
    async def invoke(self,cmd,*a,**k): return await cmd.callback(self,*a,**k)
    async def send(self,*a,**k):
        self.out.append(k if not a else dict(k,content=a[0])); return FakeMsg(self.out[-1])
def types_ns(**k):
    import types; return types.SimpleNamespace(**k)

MEMBERS={}
def conv(tp,tok,name):
    if tp is int:
        try: return int(tok)
        except Exception: raise cm.BadArgument(f'Converting to "int" failed for parameter "{name}".')
    if tp is float:
        try: return float(tok)
        except Exception: raise cm.BadArgument('float')
    if getattr(tp,'__name__','')=='Member' or str(tp).endswith('Member') or 'Member' in str(tp):
        mm=re.match(r'<@!?(\d+)>$',tok)
        if not mm or int(mm.group(1)) not in MEMBERS: raise cm.BadArgument(f'Member "{tok}" not found')
        return MEMBERS[int(mm.group(1))]
    return tok

async def dispatch(bot,content,author,prefix='!'):
    """Mimic discord.py process_commands: parse, convert, run checks, invoke, route errors to on_command_error."""
    if not content.startswith(prefix): return None
    parts=content[len(prefix):].split()
    if not parts: return None
    ctx=FakeCtx(bot,author,content,invoked=parts[0])
    cmd=bot.all_commands.get(parts[0])
    if cmd is None:
        err=cm.CommandNotFound(f'Command "{parts[0]}" is not found'); await botmod_err(bot)(ctx,err); return ctx
    ctx.command=cmd
    try:
        sig=inspect.signature(cmd.callback); params=list(sig.parameters.values())[1:]
        toks=parts[1:]; args=[]; kwargs={}; i=0
        for p in params:
            if p.kind==p.VAR_POSITIONAL: args.extend(toks[i:]); i=len(toks); break
            if p.kind==p.KEYWORD_ONLY:
                rest=' '.join(toks[i:])
                if rest: kwargs[p.name]=rest; i=len(toks)
                elif p.default is p.empty: raise _missing(p)
                continue
            if i<len(toks):
                args.append(conv(p.annotation if p.annotation is not p.empty else str,toks[i],p.name)); i+=1
            elif p.default is not p.empty: args.append(p.default)
            else: raise _missing(p)
        for chk in cmd.checks:
            r=chk(ctx); r=await r if inspect.isawaitable(r) else r
            if not r: raise cm.CheckFailure('check failed')
        try: await cmd.callback(ctx,*args,**kwargs)
        except (cm.CheckFailure,cm.BadArgument,cm.MissingRequiredArgument): raise
        except Exception as e:
            e.__traceback__=e.__traceback__; raise CommandInvokeError(e)
    except Exception as e:
        await botmod_err(bot)(ctx,e)
    return ctx
def _missing(p):
    e=cm.MissingRequiredArgument(f'{p.name} is a required argument that is missing.'); e.param=p; return e
_ERR={}
def botmod_err(bot): return _ERR['fn']
