import sys
from pathlib import Path
from unittest.mock import patch, MagicMock

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import svm_kvm


def test_name_validation():
    try:
        svm_kvm.get_vm("BAD NAME")
        assert False
    except ValueError:
        pass


def test_list_images_empty(tmp_path, monkeypatch):
    monkeypatch.setenv("KVM_IMAGE_DIR", str(tmp_path))
    assert svm_kvm.list_images() == []


def test_resolve_base(tmp_path, monkeypatch):
    p = tmp_path / "disk.qcow2"
    p.write_bytes(b"x")
    monkeypatch.setenv("KVM_BASE_IMAGE", str(p))
    assert svm_kvm.resolve_base_image() == str(p)


def test_health_structure():
    h = svm_kvm.health()
    assert "ready" in h and "missing" in h
