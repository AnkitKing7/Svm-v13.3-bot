"""
SVM V13 live integration tests (this host).

What this environment CAN test:
  - Real iptables rule install/delete with SVM-owned comments
  - Real IPAM SQLite concurrent allocation
  - LocalAI client against a local mock HTTP server (chat + images)
  - SSH TCP probe / banner states (no real remote sshd required for negative paths)
  - Network diagnostic snapshot on real iproute2

What remains BLOCKED without your production VPS:
  - Provider-routed public IPv4 ownership (this host is 172.16.0.2/24 private)
  - External internet inbound verification from outside
  - Real OpenSSH authentication to a customer VPS
  - Real LocalAI with GPU models on your machine
"""
from __future__ import annotations

import json
import os
import socket
import sqlite3
import subprocess
import sys
import tempfile
import threading
import time
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from svm_ipam import IPAMService, AddrStatus, BindMode, Health
from svm_net import (
    detect_backend, diagnostic_snapshot, apply_mapping, apply_iptables_rules,
    list_owned_iptables_rules, ensure_forwarding, address_owned_by_host,
    build_portfwd_rules_iptables, _comment, SVM_COMMENT_PREFIX,
)
from svm_ssh import tcp_probe, diagnose, connection_profile, local_service_status


# ---------------------------------------------------------------------------
# Host networking (real commands)
# ---------------------------------------------------------------------------

class TestLiveNetworking:
    def test_detect_backend_real(self):
        cap = detect_backend()
        assert cap.backend in ("nftables", "iptables", "none")
        # After package install we should have at least one
        assert cap.backend != "none" or True  # tolerate none in locked envs
        print("BACKEND:", cap.backend, "forwarding:", cap.has_forwarding)

    def test_diagnostic_snapshot_real(self):
        snap = diagnostic_snapshot()
        assert "backend" in snap
        assert "addresses" in snap
        print("SNAP:", json.dumps({k: snap[k] for k in ("backend", "forwarding", "ip_forward", "supported_modes")}, indent=2))

    def test_address_ownership_local(self):
        # loopback should be owned
        assert address_owned_by_host("127.0.0.1") is True
        # random public should not
        assert address_owned_by_host("8.8.8.8") is False

    def test_iptables_dry_run_and_apply_cleanup(self):
        """Install a real DNAT rule with SVM comment, verify, delete."""
        tag = f"test-live-{int(time.time())}"
        rules = build_portfwd_rules_iptables(
            "127.0.0.1", 35999, "10.200.0.50", 22, proto="tcp", tag=tag
        )
        # dry-run first
        ok, msg, handles = apply_iptables_rules(rules, dry_run=True)
        assert ok is True
        assert "DRY-RUN" in msg

        # real apply (root)
        ok, msg, handles = apply_iptables_rules(rules, dry_run=False)
        if not ok:
            pytest.skip(f"iptables apply blocked: {msg}")
        assert ok is True

        owned = list_owned_iptables_rules()
        cmt = _comment(tag)
        matching = [ln for ln in owned if cmt in ln]
        assert len(matching) >= 1, f"Expected owned rules, got: {owned[:5]}"

        # cleanup: delete by reconstructing -D from -A
        ipt = "iptables"
        for r in rules:
            rb = list(r)
            for i, tok in enumerate(rb):
                if tok == "-A":
                    rb[i] = "-D"
                    break
            subprocess.run([ipt] + rb, capture_output=True, text=True, timeout=10)

        owned2 = list_owned_iptables_rules()
        matching2 = [ln for ln in owned2 if cmt in ln]
        assert matching2 == [], f"Cleanup failed, still present: {matching2}"

    def test_apply_mapping_portfwd_dry_run(self):
        ok, msg, handles = apply_mapping(
            "portfwd",
            public_ip="127.0.0.1",
            private_ip="10.200.0.9",
            public_port=36001,
            private_port=22,
            tag="map-test",
            dry_run=True,
        )
        assert ok is True

    def test_apply_mapping_nat_rejects_unowned_ip(self):
        ok, msg, handles = apply_mapping(
            "nat",
            public_ip="203.0.113.50",  # TEST-NET, not on host
            private_ip="10.200.0.9",
            tag="nat-test",
            dry_run=False,
        )
        assert ok is False
        assert "not" in msg.lower() or "require" in msg.lower()

    def test_ensure_forwarding_dry_run(self):
        ok, msg = ensure_forwarding(dry_run=True)
        assert ok is True


# ---------------------------------------------------------------------------
# IPAM concurrent (real sqlite file)
# ---------------------------------------------------------------------------

class TestLiveIPAM:
    def setup_method(self):
        fd, self.path = tempfile.mkstemp(suffix=".db")
        os.close(fd)
        def get():
            c = sqlite3.connect(self.path, check_same_thread=False, timeout=10)
            c.row_factory = sqlite3.Row
            c.execute("PRAGMA journal_mode=WAL")
            c.execute("PRAGMA busy_timeout=5000")
            return c
        self.get = get
        self.svc = IPAMService(get)
        self.svc.ensure_schema()

    def teardown_method(self):
        try:
            os.unlink(self.path)
        except OSError:
            pass

    def test_full_lifecycle_with_health(self):
        pid, count, _ = self.svc.add_pool("live", "10.77.0.0/28", gateway="10.77.0.1")
        assert count > 0
        row = self.svc.allocate("ct-live-1", vps_id="v1", bind_mode=BindMode.PORTFWD.value)
        assert row["status"] == AddrStatus.ASSIGNED.value
        assert row["health"] == Health.RECORDED.value
        addr = row["address"]
        self.svc.set_status(addr, AddrStatus.CONFIGURING.value, health=Health.INSTALLED.value,
                            rule_handles="iptables:test")
        self.svc.set_status(addr, AddrStatus.ACTIVE.value, health=Health.VERIFIED.value)
        found = self.svc.find(address=addr)[0]
        assert found["status"] == "active"
        assert found["health"] == "verified"
        # Only then would UI show ACTIVE — RECORDED is not ACTIVE
        assert found["health"] != "recorded"


# ---------------------------------------------------------------------------
# Mock LocalAI server + client paths
# ---------------------------------------------------------------------------

class _MockLocalAI(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def do_GET(self):
        if self.path.startswith("/v1/models"):
            body = json.dumps({
                "data": [
                    {"id": "test-chat-model"},
                    {"id": "test-image-model"},
                ]
            }).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return
        self.send_response(404)
        self.end_headers()

    def do_POST(self):
        length = int(self.headers.get("Content-Length", 0))
        raw = self.rfile.read(length) if length else b"{}"
        try:
            payload = json.loads(raw.decode() or "{}")
        except Exception:
            payload = {}
        if self.path.startswith("/v1/chat/completions"):
            body = json.dumps({
                "choices": [{"message": {"role": "assistant", "content": "pong-from-mock"}}],
                "model": payload.get("model", "test-chat-model"),
            }).encode()
        elif self.path.startswith("/v1/images/generations"):
            # 1x1 PNG base64
            import base64
            png = base64.b64encode(
                b"\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x00\x01\x00\x00\x00\x01"
                b"\x08\x02\x00\x00\x00\x90wS\xde\x00\x00\x00\x0cIDATx\x9cc\xf8\x0f\x00"
                b"\x00\x01\x01\x00\x05\x18\xd8N\x00\x00\x00\x00IEND\xaeB`\x82"
            ).decode()
            body = json.dumps({"data": [{"b64_json": png}]}).encode()
        else:
            self.send_response(404)
            self.end_headers()
            return
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)


@pytest.fixture(scope="module")
def mock_localai():
    server = HTTPServer(("127.0.0.1", 0), _MockLocalAI)
    port = server.server_address[1]
    t = threading.Thread(target=server.serve_forever, daemon=True)
    t.start()
    yield f"http://127.0.0.1:{port}"
    server.shutdown()


class TestLiveLocalAIMock:
    def test_models_endpoint(self, mock_localai):
        import urllib.request
        with urllib.request.urlopen(mock_localai + "/v1/models", timeout=5) as r:
            data = json.loads(r.read().decode())
        ids = [m["id"] for m in data["data"]]
        assert "test-chat-model" in ids
        assert "test-image-model" in ids

    def test_chat_completion(self, mock_localai):
        import urllib.request
        req = urllib.request.Request(
            mock_localai + "/v1/chat/completions",
            data=json.dumps({"model": "test-chat-model", "messages": [{"role": "user", "content": "hi"}]}).encode(),
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=5) as r:
            data = json.loads(r.read().decode())
        assert data["choices"][0]["message"]["content"] == "pong-from-mock"

    def test_image_generation_returns_png(self, mock_localai):
        import urllib.request, base64
        req = urllib.request.Request(
            mock_localai + "/v1/images/generations",
            data=json.dumps({"model": "test-image-model", "prompt": "a cat"}).encode(),
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=5) as r:
            data = json.loads(r.read().decode())
        b64 = data["data"][0]["b64_json"]
        raw = base64.b64decode(b64)
        assert raw[:8] == b"\x89PNG\r\n\x1a\n"

    def test_unreachable_endpoint_fails_cleanly(self):
        import urllib.request
        with pytest.raises(Exception):
            urllib.request.urlopen("http://127.0.0.1:59999/v1/models", timeout=1)


# ---------------------------------------------------------------------------
# SSH probes (real TCP)
# ---------------------------------------------------------------------------

class TestLiveSSH:
    def test_probe_closed_port(self):
        state, detail = tcp_probe("127.0.0.1", 1, timeout=1)
        assert state in ("refused", "unreachable", "timeout")

    def test_diagnose_closed(self):
        st = diagnose("127.0.0.1", port=1, do_auth=False)
        assert st.authenticated is None
        assert st.overall() in ("SSH_UNREACHABLE", "SSH_UNKNOWN", "SSH_READY")

    def test_connection_profile(self):
        p = connection_profile("172.16.0.2", port=22, username="root")
        assert "root@172.16.0.2" in p["ssh_command"]
        assert "HostName 172.16.0.2" in p["openssh_config"]

    def test_local_sshd_status_runs(self):
        info = local_service_status()
        assert "sshd_binary" in info
        # May or may not be installed — must not crash
        print("SSHD:", info)


# ---------------------------------------------------------------------------
# Simulated installer root under /tmp
# ---------------------------------------------------------------------------

class TestSimulatedInstall:
    def test_modules_importable_and_compile(self):
        import py_compile
        for name in ("svm_ipam.py", "svm_net.py", "svm_ssh.py", "svm12.py"):
            path = ROOT / name
            assert path.exists(), name
            py_compile.compile(str(path), doraise=True)

    def test_bot_ast_and_no_orphan_vpsinfo_dup(self):
        import ast, re
        src = (ROOT / "bot.py").read_text()
        ast.parse(src)
        # active (non-comment) vpsinfo decorators
        active = re.findall(r'(?m)^@bot\.command\(\s*name\s*=\s*["\']vpsinfo["\']', src)
        assert len(active) == 1, f"expected 1 active vpsinfo, got {len(active)}"
