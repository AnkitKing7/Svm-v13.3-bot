"""DNS + tool registry unit tests for SVM V13."""
from __future__ import annotations

import sys
from pathlib import Path
from unittest.mock import patch

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from svm_dns import (
    validate_label, validate_fqdn, generate_hostname, sanitize_id,
    verify_a_record, verify_hostname_live, DNSConfig, resolve_a,
)
from svm_tools import ToolRegistry, ToolSpec, ToolGroup, ToolScope, build_default_registry


class TestHostname:
    def test_sanitize(self):
        assert sanitize_id("My VPS #1") == "my-vps-1"

    def test_labels(self):
        assert validate_label("vps-42")
        assert not validate_label("-bad")
        assert validate_fqdn("vps-1.example.com")
        assert not validate_fqdn("")

    def test_generate_with_suffix(self):
        cfg = DNSConfig(domain_suffix="cust.example.com", template="vps-{id}")
        h = generate_hostname("99", cfg=cfg)
        assert h == "vps-99.cust.example.com"

    def test_generate_override_fqdn(self):
        h = generate_hostname("1", override="app.example.org", cfg=DNSConfig())
        assert h == "app.example.org"

    def test_generate_invalid_override(self):
        with pytest.raises(ValueError):
            generate_hostname("1", override="-nope-", cfg=DNSConfig())


class TestDNSResolve:
    def test_resolve_localhost(self):
        addrs, err = resolve_a("localhost", timeout=3)
        # may be ::1 and/or 127.0.0.1 depending on system
        assert err == "" or addrs  # at least one path works on most systems
        # Soft: if resolver works, we should see loopback family
        if addrs:
            assert any(a.startswith("127.") or a == "::1" for a in addrs)

    def test_verify_mismatch(self):
        res = verify_a_record("localhost", "8.8.8.8", timeout=3)
        # localhost should not be 8.8.8.8
        if res.answers:
            assert res.matched is False

    def test_verify_hostname_live_structure(self):
        out = verify_hostname_live("localhost", "127.0.0.1")
        assert "ok" in out and "answers" in out and "hostname" in out


class TestToolRegistry:
    def test_default_counts_honest(self):
        reg = build_default_registry()
        c = reg.counts()
        assert c["total_registered"] >= 8
        assert c["total_registered"] < 100  # sanity: not fake 1000+
        assert "note" in c

    def test_list_and_get(self):
        reg = build_default_registry()
        tools = reg.list(enabled_only=True)
        assert any(t["id"] == "dns_verify_a" for t in tools)
        assert reg.get("dns_verify_a") is not None

    def test_duplicate_rejected(self):
        reg = ToolRegistry()
        reg.register(ToolSpec("t1", "d", ToolGroup.SYSTEM, ToolScope.READ))
        with pytest.raises(ValueError):
            reg.register(ToolSpec("t1", "d", ToolGroup.SYSTEM, ToolScope.READ))

    def test_mutate_requires_flag(self):
        reg = build_default_registry()
        out = reg.invoke("nat_apply_mapping", {}, allow_mutate=False)
        assert out["ok"] is False

    def test_invoke_dns_generate(self):
        reg = build_default_registry()
        out = reg.invoke("dns_generate_hostname", {"vps_id": "7"})
        assert out["ok"] is True
        assert "hostname" in (out.get("result") or {})

    def test_invoke_ssh_probe(self):
        reg = build_default_registry()
        out = reg.invoke("ssh_tcp_diagnose", {"host": "127.0.0.1", "port": 1})
        assert out["ok"] is True
        assert "overall" in (out.get("result") or {})

    def test_system_counts_tool(self):
        reg = build_default_registry()
        out = reg.invoke("system_tool_counts", {})
        assert out["ok"] is True
        assert out["result"]["total_registered"] >= 1
