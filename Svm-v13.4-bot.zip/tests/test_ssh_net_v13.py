"""
SVM V13 SSH + networking unit tests (mocked / non-mutating).
"""
from __future__ import annotations

import sys
from pathlib import Path
from unittest.mock import patch, MagicMock

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from svm_ssh import (
    tcp_probe, connection_profile, diagnose, SSHStatus,
    detect_sshd_service, local_service_status, DEFAULT_USER, DEFAULT_PORT,
)
from svm_net import (
    detect_backend, diagnostic_snapshot, build_portfwd_rules_iptables,
    build_nat11_rules_iptables, apply_mapping, _comment, SVM_COMMENT_PREFIX,
)


class TestSSHHelpers:
    def test_connection_profile_shape(self):
        p = connection_profile("203.0.113.10", port=2222, username="root")
        assert p["username"] == "root"
        assert p["port"] == "2222"
        assert "ssh -p 2222 root@203.0.113.10" in p["ssh_command"]
        assert "HostName 203.0.113.10" in p["openssh_config"]
        assert "termius_hint" in p

    def test_defaults(self):
        assert DEFAULT_USER == "root"
        assert DEFAULT_PORT == 22

    def test_tcp_probe_refused(self):
        # Port that should be closed on localhost
        state, detail = tcp_probe("127.0.0.1", 1, timeout=1)
        assert state in ("refused", "unreachable", "timeout")

    def test_diagnose_no_auth(self):
        st = diagnose("127.0.0.1", port=1, do_auth=False)
        assert isinstance(st, SSHStatus)
        assert st.overall() in ("SSH_UNREACHABLE", "SSH_UNKNOWN", "SSH_READY")
        assert st.authenticated is None  # not attempted

    def test_local_service_status_runs(self):
        # May or may not have sshd in this environment — just must not crash
        info = local_service_status()
        assert "sshd_binary" in info
        assert "config_test_ok" in info


class TestNetBackend:
    def test_detect_backend_runs(self):
        cap = detect_backend()
        assert cap.backend in ("nftables", "iptables", "none")
        assert isinstance(cap.supported_modes(), list)
        assert "record" in cap.supported_modes()

    def test_diagnostic_snapshot(self):
        snap = diagnostic_snapshot()
        assert "backend" in snap
        assert "supported_modes" in snap

    def test_comment_prefix(self):
        c = _comment("test-vm-1")
        assert c.startswith(SVM_COMMENT_PREFIX)
        assert "test-vm-1" in c

    def test_build_portfwd_rules(self):
        rules = build_portfwd_rules_iptables("203.0.113.1", 2222, "10.0.0.5", 22, tag="vps1")
        assert len(rules) >= 2
        flat = " ".join(" ".join(r) for r in rules)
        assert "DNAT" in flat
        assert "10.0.0.5:22" in flat
        assert SVM_COMMENT_PREFIX in flat

    def test_build_nat11(self):
        rules = build_nat11_rules_iptables("203.0.113.50", "10.0.0.50", tag="nat1")
        flat = " ".join(" ".join(r) for r in rules)
        assert "DNAT" in flat and "SNAT" in flat

    def test_apply_record_mode(self):
        ok, msg, handles = apply_mapping("record", public_ip="1.2.3.4", private_ip="10.0.0.1", dry_run=True)
        assert ok is True
        assert handles == []

    def test_apply_portfwd_dry_run(self):
        ok, msg, handles = apply_mapping(
            "portfwd", public_ip="127.0.0.1", private_ip="10.0.0.2",
            public_port=2222, private_port=22, dry_run=True)
        # dry-run should succeed even without root
        assert ok is True
        assert "DRY-RUN" in msg or handles
