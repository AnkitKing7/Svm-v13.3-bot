# SVM Advanced AI V14 — Ultra Networking & Public IPv4 Mapping

**Made by AnkitCoder**

## From V13 → V14

| Area | Change |
|------|--------|
| Topology | `svm_topology.py` — DIRECT_PUBLIC / UPSTREAM_NAT / CGNAT / PROVIDER_ROUTED / PRIVATE_ONLY / UNKNOWN |
| Mapping engine | `svm_map.py` — modes A–E with dry-run, confirm, verify states |
| Verify states | RECORDED → INSTALLED → LOCAL_VERIFIED → EXTERNAL_VERIFIED (+ FAILED/DRIFT/…) |
| WireGuard | Config guidance only; never equals public IPv4; no stored private keys |
| Safety | No firewall flush; no default-route replace; operator_confirmed for live apply |

## Mapping modes

- **A portfwd** — shared public IP:port → private:port (TCP/UDP)
- **B nat** — 1:1 when address owned / authorized
- **C routed** — provider-routed; no invented gateways
- **D wireguard** — optional tunnel overlay
- **E record** — database only

Documentation-only examples like `203.0.113.10` are never used as live production claims.

## Upgrade

```bash
sudo bash install.sh upgrade
sudo bash install.sh doctor
sudo bash install.sh test
```

Backups: `db_backups/pre-v13-*` style snapshots continue; code under `backups/`.

## Rollback

```bash
sudo bash install.sh rollback
```

## Honest limits

EXTERNAL_VERIFIED requires an independent external probe on your real public IP — not available in generic CI sandboxes.
