"""
SVM V13 — Typed AI / ops tool registry
Made by AnkitCoder.

Honest counts: only tools actually registered here are counted.
Read-only vs mutating scopes. Availability checks are explicit.
"""
from __future__ import annotations

import inspect
import logging
import time
from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Sequence

logger = logging.getLogger("svm.tools")


class ToolScope(str, Enum):
    READ = "read"
    MUTATE = "mutate"
    ADMIN = "admin"


class ToolGroup(str, Enum):
    IPAM = "ipam"
    NAT = "nat"
    SSH = "ssh"
    DNS = "dns"
    FILES = "files"
    NODES = "nodes"
    VIRT = "virt"
    AI = "ai"
    DIAG = "diagnostics"
    SYSTEM = "system"


@dataclass
class ToolSpec:
    id: str
    description: str
    group: ToolGroup
    scope: ToolScope
    handler: Optional[Callable] = None
    input_schema: Dict[str, Any] = field(default_factory=dict)
    timeout_sec: float = 30.0
    enabled: bool = True
    requires_confirm: bool = False
    tested: bool = False  # set True only when a test asserts this tool

    def meta(self) -> Dict[str, Any]:
        d = {
            "id": self.id,
            "description": self.description,
            "group": self.group.value,
            "scope": self.scope.value,
            "timeout_sec": self.timeout_sec,
            "enabled": self.enabled,
            "requires_confirm": self.requires_confirm,
            "tested": self.tested,
            "input_schema": self.input_schema,
            "has_handler": self.handler is not None,
        }
        return d


class ToolRegistry:
    def __init__(self):
        self._tools: Dict[str, ToolSpec] = {}

    def register(self, spec: ToolSpec) -> None:
        if not spec.id or not re_match_id(spec.id):
            raise ValueError(f"Invalid tool id: {spec.id!r}")
        if spec.id in self._tools:
            raise ValueError(f"Duplicate tool id: {spec.id}")
        self._tools[spec.id] = spec

    def get(self, tool_id: str) -> Optional[ToolSpec]:
        return self._tools.get(tool_id)

    def list(self, *, group: Optional[str] = None, scope: Optional[str] = None,
             enabled_only: bool = False) -> List[Dict[str, Any]]:
        out = []
        for t in self._tools.values():
            if group and t.group.value != group:
                continue
            if scope and t.scope.value != scope:
                continue
            if enabled_only and not t.enabled:
                continue
            out.append(t.meta())
        out.sort(key=lambda x: (x["group"], x["id"]))
        return out

    def counts(self) -> Dict[str, Any]:
        tools = list(self._tools.values())
        by_group: Dict[str, int] = {}
        by_scope: Dict[str, int] = {}
        for t in tools:
            by_group[t.group.value] = by_group.get(t.group.value, 0) + 1
            by_scope[t.scope.value] = by_scope.get(t.scope.value, 0) + 1
        return {
            "total_registered": len(tools),
            "enabled": sum(1 for t in tools if t.enabled),
            "disabled": sum(1 for t in tools if not t.enabled),
            "with_handler": sum(1 for t in tools if t.handler is not None),
            "tested": sum(1 for t in tools if t.tested),
            "mutate": sum(1 for t in tools if t.scope == ToolScope.MUTATE),
            "read": sum(1 for t in tools if t.scope == ToolScope.READ),
            "admin": sum(1 for t in tools if t.scope == ToolScope.ADMIN),
            "by_group": by_group,
            "by_scope": by_scope,
            "note": "Counts are registry entries only — not inflated marketing numbers.",
        }

    def invoke(self, tool_id: str, args: Optional[dict] = None, *,
               allow_mutate: bool = False, confirmed: bool = False) -> Dict[str, Any]:
        spec = self._tools.get(tool_id)
        if not spec:
            return {"ok": False, "error": f"unknown tool: {tool_id}"}
        if not spec.enabled:
            return {"ok": False, "error": "tool disabled"}
        if spec.scope in (ToolScope.MUTATE, ToolScope.ADMIN) and not allow_mutate:
            return {"ok": False, "error": "mutating tools require allow_mutate=True"}
        if spec.requires_confirm and not confirmed:
            return {"ok": False, "error": "confirmation required"}
        if not spec.handler:
            return {"ok": False, "error": "no handler bound"}
        args = args or {}
        t0 = time.time()
        try:
            result = spec.handler(**args) if _accepts_kwargs(spec.handler) else spec.handler(args)
            return {
                "ok": True,
                "tool": tool_id,
                "result": result,
                "duration_ms": int((time.time() - t0) * 1000),
            }
        except TypeError as e:
            return {"ok": False, "error": f"bad args: {e}", "tool": tool_id}
        except Exception as e:
            logger.exception("tool %s failed", tool_id)
            return {"ok": False, "error": str(e), "tool": tool_id}


def re_match_id(s: str) -> bool:
    import re
    return bool(re.fullmatch(r"[a-z][a-z0-9_]{1,63}", s))


def _accepts_kwargs(fn: Callable) -> bool:
    try:
        sig = inspect.signature(fn)
        return any(
            p.kind in (p.VAR_KEYWORD, p.KEYWORD_ONLY) or p.default is not p.empty
            for p in sig.parameters.values()
        ) or all(p.kind == p.POSITIONAL_OR_KEYWORD for p in sig.parameters.values())
    except Exception:
        return True


def build_default_registry() -> ToolRegistry:
    """Register real SVM V13 capabilities (honest, not 1000 fake tools)."""
    reg = ToolRegistry()

    def _diag_net():
        try:
            from svm_net import diagnostic_snapshot
            return diagnostic_snapshot()
        except Exception as e:
            return {"error": str(e)}

    def _ipam_inventory():
        return {"hint": "Use IPAMService.inventory() with live DB connection"}

    def _dns_verify(hostname: str = "", expected_ip: str = ""):
        from svm_dns import verify_hostname_live
        if not hostname:
            return {"ok": False, "error": "hostname required"}
        return verify_hostname_live(hostname, expected_ip or None)

    def _ssh_probe(host: str = "127.0.0.1", port: int = 22):
        from svm_ssh import diagnose
        return diagnose(host, port=int(port), do_auth=False).as_dict()

    def _hostname_gen(vps_id: str = "demo"):
        from svm_dns import generate_hostname
        return {"hostname": generate_hostname(vps_id)}

    tools = [
        ToolSpec("net_diagnostic", "Host network diagnostic snapshot", ToolGroup.DIAG, ToolScope.READ,
                 handler=_diag_net, tested=True),
        ToolSpec("ipam_inventory_hint", "IPAM inventory requires DB (hint only)", ToolGroup.IPAM, ToolScope.READ,
                 handler=_ipam_inventory, tested=True),
        ToolSpec("dns_verify_a", "Verify public/system A record for hostname", ToolGroup.DNS, ToolScope.READ,
                 handler=_dns_verify, input_schema={"hostname": "str", "expected_ip": "str"}, tested=True),
        ToolSpec("dns_generate_hostname", "Generate stable hostname from template", ToolGroup.DNS, ToolScope.READ,
                 handler=_hostname_gen, input_schema={"vps_id": "str"}, tested=True),
        ToolSpec("ssh_tcp_diagnose", "TCP/banner SSH diagnose (no auth)", ToolGroup.SSH, ToolScope.READ,
                 handler=_ssh_probe, input_schema={"host": "str", "port": "int"}, tested=True),
        ToolSpec("nat_apply_mapping", "Apply NAT/portfwd mapping (mutating)", ToolGroup.NAT, ToolScope.MUTATE,
                 handler=None, requires_confirm=True, enabled=True,
                 input_schema={"mode": "str", "public_ip": "str", "private_ip": "str"}),
        ToolSpec("files_list_sftp", "List remote directory via SFTP", ToolGroup.FILES, ToolScope.READ,
                 handler=None, input_schema={"host": "str", "path": "str"}),
        ToolSpec("files_upload_sftp", "Upload file via SFTP", ToolGroup.FILES, ToolScope.MUTATE,
                 handler=None, requires_confirm=True),
        ToolSpec("system_tool_counts", "Honest registry metrics", ToolGroup.SYSTEM, ToolScope.READ,
                 handler=lambda: None, tested=True),  # rebound below
    ]
    for spec in tools:
        reg.register(spec)

    # bind counts tool to registry itself
    reg.get("system_tool_counts").handler = reg.counts  # type: ignore
    return reg


# Module-level singleton for importers
DEFAULT_REGISTRY = build_default_registry()
