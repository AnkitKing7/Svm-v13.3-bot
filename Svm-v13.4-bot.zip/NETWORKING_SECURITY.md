# Networking Security — V14

- Discovery is read-only by default
- Live NAT/portfwd requires operator confirmation
- Secrets never written to ips.txt / ips.json
- File mode 0640 on inventory files
- Concurrent writes serialized with a lock + atomic replace
